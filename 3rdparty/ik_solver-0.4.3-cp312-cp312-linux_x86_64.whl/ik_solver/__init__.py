"""
IK Solver Package
================

这是一个基于 C++ 实现的机器人逆运动学求解器的 Python 接口。

主要功能：
- 支持 URDF 模型导入
- 支持松弛 IK 求解
- 支持多种目标更新方式（矩阵、四元数）
"""

import os
import sys

# 添加库路径
lib_path = os.path.join(os.path.dirname(__file__), 'lib')
if sys.platform == 'linux':
    os.environ['LD_LIBRARY_PATH'] = f"{lib_path}:{os.environ.get('LD_LIBRARY_PATH', '')}"


from typing import Tuple, List, Union, Optional
import numpy as np
from enum import Enum
import logging

# 从类型定义模块导入类型
from .typing import (
    Vector3, Vector4,
    Matrix3, Matrix4
)

# 从 C++ 模块导入核心功能
from ._core import Solver as _Solver
from ._core import RobotPart as _RobotPart

# 版本信息
__author__ = "Wang Wenhao"

class RobotPart(Enum):
    """机器人部件枚举类型"""
    DUAL_ARM = _RobotPart.DUAL_ARM
    LEFT_ARM = _RobotPart.LEFT_ARM
    REDUCED_LEFT_ARM = _RobotPart.REDUCED_LEFT_ARM
    RIGHT_ARM = _RobotPart.RIGHT_ARM
    REDUCED_RIGHT_ARM = _RobotPart.REDUCED_RIGHT_ARM
    HEAD = _RobotPart.HEAD
    FULL_BODY = _RobotPart.FULL_BODY

class Solver:
    """IK求解器类，提供机器人运动学求解功能。
    
    这个类封装了C++实现的IK求解器，提供了友好的Python接口。
    支持多种目标更新方式（矩阵、四元数）。
    """
    
    def __init__(self, part: RobotPart, urdf_path: str, config_path: str) -> None:
        """初始化IK求解器
        
        Args:
            part: 机器人部件
            urdf_path: URDF文件路径
            config_path: 优化器配置文件路径
        """
        self._solver = _Solver(part._value_, urdf_path, config_path)
    
    def set_debug_mode(self, enable: bool) -> None:
        """设置是否启用调试输出
        
        Args:
            enable: 是否启用调试输出
        """
        self._solver.set_debug_mode(enable)
    
    def get_debug_mode(self) -> bool:
        """获取当前调试输出状态
        
        Returns:
            bool: 当前是否启用调试输出
        """
        return self._solver.get_debug_mode()
    
    def sync_target_with_joints(self, init_state: np.ndarray) -> None:
        """根据当前关节角度更新目标位姿
        
        Args:
            init_state: 初始关节角度
        """
        self._solver.sync_target_with_joints(init_state)
    
    def update_target_mat(self, target_pos: Vector3, target_rot: Matrix3, target_index: int = 0) -> None:
        """使用位置和旋转矩阵更新目标
        
        Args:
            target_pos: 目标位置 (3维)
            target_rot: 目标旋转矩阵 (3x3)
            target_index: 目标索引，默认为0
        """
        self._solver.update_target_mat(target_pos, target_rot, target_index)
    
    def update_target_quat(self, target_pos: Vector3, target_quat: Vector4, target_index: int = 0) -> None:
        """使用位置和四元数更新目标
        
        Args:
            target_pos: 目标位置 (3维)
            target_quat: 目标四元数 (x,y,z,w)
            target_index: 目标索引，默认为0
        """
        self._solver.update_target_quat(target_pos, target_quat, target_index)
    
    def solve(self) -> np.ndarray:
        """求解IK
        
        Returns:
            关节角度解
        """
        return self._solver.solve()
    
    def get_current_state(self) -> np.ndarray:
        """获取当前关节状态
        
        Returns:
            当前关节角度
        """
        return self._solver.get_current_state()
    
    def get_current_target(self) -> List[Matrix4]:
        """获取当前目标位姿列表
        
        Returns:
            目标位姿列表，每个位姿为4x4矩阵
        """
        return self._solver.get_current_target()
    
    def get_part(self) -> RobotPart:
        """获取当前控制的机器人部位
        
        Returns:
            当前控制的机器人部位
        """
        return RobotPart(self._solver.get_part())

    def compute_fk(self, q: np.ndarray) -> List[Matrix4]:
        """计算给定关节角度的前向运动学
        
        Args:
            q: 关节角度

        Returns:
            位姿列表，每个位姿为4x4矩阵。对于机械臂，返回末端执行器、手腕和肘部的位姿；
            对于头部，只返回末端执行器的位姿。
        """
        return self._solver.compute_fk(q)

# 明确指定可以从包中导入的符号
__all__ = [
    'Solver',
    'RobotPart',
    'Vector3',
    'Vector4',
    'Matrix3',
    'Matrix4',
    '__author__'
]

# 配置日志
logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())  # 避免"无处理程序"警告

def _check_environment() -> None:
    """检查运行环境是否满足要求"""
    try:
        import numpy
        logger.debug(f"Found numpy version {numpy.__version__}")
    except ImportError:
        logger.warning("NumPy is required for optimal performance")

_check_environment()
