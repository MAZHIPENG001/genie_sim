"""
类型定义模块
===========

为IK求解器定义的类型别名，用于提供更好的IDE支持和类型检查。
"""

from typing import Tuple, List, Union, Optional
import numpy as np
import numpy.typing as npt

# 类型别名定义
Vector2 = npt.NDArray[np.float64]  # 2维向量 (头部关节角度)
Vector3 = npt.NDArray[np.float64]  # 3维向量 (位置/RPY角)
Vector4 = npt.NDArray[np.float64]  # 4维向量 (四元数 x,y,z,w)
Vector7 = npt.NDArray[np.float64]  # 7维向量 (机械臂关节角度)
Vector18 = npt.NDArray[np.float64]  # 18维向量 (完整机器人状态)
Matrix3 = npt.NDArray[np.float64]  # 3x3矩阵 (旋转矩阵)
Matrix4 = npt.NDArray[np.float64]  # 4x4矩阵 (变换矩阵)

# 类型别名导出
__all__ = [
    'Vector2',
    'Vector3',
    'Vector4',
    'Vector7',
    'Vector18',
    'Matrix3',
    'Matrix4'
] 